#!/usr/bin/env python3
from urllib.parse import urlparse
from socket import socket, AF_INET, SOCK_STREAM, gethostbyname, gaierror, timeout
import ssl
from OpenSSL import crypto
from datetime import datetime
import click

import logging
from sys import stdout

logging.basicConfig(stream=stdout, level=logging.INFO, format='%(message)s')


@click.command()
@click.option("--url", help="Enter the URL/Link.")
@click.option("--port", default=443, help="Enter the URL/Link.")
def check_url(url, port):
    if url:
        result = parse_url(url, port)
        if result:
            cert = ssl.get_server_certificate((result, port))
            x509 = crypto.load_certificate(crypto.FILETYPE_PEM, cert)
            logging.info(datetime.strptime(x509.get_notAfter().decode('ascii'), '%Y%m%d%H%M%SZ'))
        else:
            logging.error("Error occurred while fetching ssl expiry date")
    else:
        logging.info("""URL is missing !!
        Usage:
        python check_expiry.py --help
        python check_expiry.py --url google.com
        ./check_expiry.py --url google.com
        """)


def parse_url(url, port):
    domain = urlparse(url).netloc
    try:
        if len(domain) > 3:
            ip_addr = gethostbyname(domain)
            port_status = check_port(ip_addr, port)
            if port_status:
                return ip_addr
            else:
                return None
        else:
            logging.error('Provided URL is invalid')
            return None
    except (gaierror, timeout):
        logging.error('Could not find host {0}. Please check the name and try again.'.format(domain))
        return None


def check_port(ip_addr, port):
    tcp_socket = socket(AF_INET, SOCK_STREAM)
    tcp_socket.settimeout(10.0)
    location = (ip_addr, port)
    result = tcp_socket.connect_ex(location)
    if result == 0:
        return True
    else:
        logging.error('This URL does not have a valid SSL endpoint')
        return False


if __name__ == '__main__':
    check_url()
