## Get SSL Expiry date
```
sudo apt-get install build-essential libssl-dev libffi-dev python3-dev cargo python3-pip
pip3 install -r requirements.txt
```
# Usage
```
python check_expiry --help
python check_expiry --url google.com
./check_expiry --url google.com
./check_expiry --url google.com --port 8443
```
Note: Default port number is 443