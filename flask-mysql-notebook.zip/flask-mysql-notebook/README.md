## Python Flask with MySQL

Basic Flask app that lets you store records to MySQL, search from MySQL and also display the number of records on the MySQL Table.

### Setup Dependencies:

```
sudo apt install build-essential python-dev libmysqlclient-dev
```

### Download, Install Requirements:

```bash
cd flask-mysql-notebook
pip install -r requirements.txt
```

### MySQL Configuration: 

```
vi application.py
```

### Run Application:
```
python application.py
```

### Run Application in Docker-Compose:
```
docker-compose up -d
```

### Run Application in Kubernetes:
```
kubectl apply  -f kubernetes.yaml
```
